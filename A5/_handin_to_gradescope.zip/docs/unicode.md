# Part 3 Unicode

### 1. Who founded the Consortium? Who is represented among the current members, and how might that affect decisions being made for Unicode?



### 2. Find a language that is not yet in Unicode, has only recently been supported (e.g., in the last 10 years), or is/was missing important characters. What is/was missing, and how does this affect the users of the language?



### 3. For this question, you will need to work with a classmate! Make sure to coordinate so that you outline opposing positions for Part A (e.g. if you outline the ‘for’ position, your partner defends the ‘against’ position). Then, come together and discuss Part B!




#### Step A: Outline either the position for or against Han Unification



#### Step B
### A bullet-point summary of your discussion for Step B


#### Describe the tradeoff that Unicode has made with this decision 
